--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pharmacymanager;
--
-- Name: pharmacymanager; Type: DATABASE; Schema: -; Owner: pharmacymanager
--

CREATE DATABASE pharmacymanager WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Bulgarian_Bulgaria.1251';


ALTER DATABASE pharmacymanager OWNER TO pharmacymanager;

\connect pharmacymanager

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: medicines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medicines (
    id uuid NOT NULL,
    manufacturer text,
    name text,
    description text,
    "manufacturingDate" date,
    "expirationDate" date,
    price numeric(30,8),
    quantity bigint,
    deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.medicines OWNER TO postgres;

--
-- Data for Name: medicines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medicines (id, manufacturer, name, description, "manufacturingDate", "expirationDate", price, quantity, deleted) FROM stdin;
\.
COPY public.medicines (id, manufacturer, name, description, "manufacturingDate", "expirationDate", price, quantity, deleted) FROM '$$PATH$$/4780.dat';

--
-- Name: medicines id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT id_unique UNIQUE (id);


--
-- Name: medicines medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT medicines_pkey PRIMARY KEY (id);


--
-- Name: DATABASE pharmacymanager; Type: ACL; Schema: -; Owner: pharmacymanager
--

REVOKE ALL ON DATABASE pharmacymanager FROM pharmacymanager;
GRANT CREATE,CONNECT ON DATABASE pharmacymanager TO pharmacymanager;
GRANT TEMPORARY ON DATABASE pharmacymanager TO pharmacymanager WITH GRANT OPTION;


--
-- Name: TABLE medicines; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.medicines TO pharmacymanager WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

